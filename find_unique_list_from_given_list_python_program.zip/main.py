'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
lst = []
 
n = int(input("Enter number of elements :"))
print("Enter the elements :")
 
for i in range(0, n):
    ele = int(input())
 
    lst.append(ele)
     
print("Entered list is :",lst)

def unique_list(lst):
  x = []
  for a in lst:
    if a not in x:
      x.append(a)
  return x

print("Unique list is :",unique_list(lst)) 